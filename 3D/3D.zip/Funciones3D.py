from datetime import datetime, timezone
import matplotlib.pyplot as plt
import json
import math
import numpy as np


R_TIERRA = 6378.137      # radio de la Tierra en km (el que usa fisica_orbital.py)
MU = 398600.0            # constante gravitacional de la Tierra, km^3/s^2
DIA_SIDEREO = 86164.0    # segundos que tarda la Tierra en dar una vuelta (23 h 56 min)

# Datos cargados

def leer_satelites(ruta: str) -> list:

    """
    ... lee el archivo JSON (con codificación utf-8) y devuelve la lista de registros. 
    ... Si el archivo no existe, imprime un aviso y devuelve una lista vacía.
    """

    try:
        with open (ruta, "r", encoding="utf-8") as f:
            datos = json.load(f)
            return datos
    except FileNotFoundError:
        print(f"Advertencia: El archivo '{ruta}' no existe.")
        return []


def inspeccionar_satelite(satelite):
    """
    Lista todos los campos disponibles de un satélite y verifica si cuenta
    con los parámetros orbitales necesarios para dibujar su órbita.
    """
    datos = {}

    nombre = satelite.get("OBJECT_NAME")
    print(f"Nombre del satelite: {nombre}")

    # 1. Listar todos los campos que trae este diccionario
    for clave, valor in satelite.items():
        if valor is not None:
            datos[clave] = valor

    # 2. Verificar si faltan RAAN o Argumento del perigeo
    faltantes = []

    if "RA_OF_ASC_NODE" not in datos:
        datos["RA_OF_ASC_NODE"] = 0
        faltantes.append("RAAN")

    if "ARG_OF_PERICENTER" not in datos:
        datos["ARG_OF_PERICENTER"] = 0
        faltantes.append("Argumento del perigeo")

    # Guardamos el aviso en el mismo diccionario para usarlo después en el gráfico
    if faltantes:
        datos["aviso_grafico"] = f"Aviso: {', '.join(faltantes)} asumido(s) en 0"
    else:
        datos["aviso_grafico"] = "No hay parametros faltantes"

    return datos


def calcular_parametros_fisicos(satelite):

    """
    ... Recibe el diccionario de un satélite y devuelve un nuevo diccionario
    ... con el semieje mayor (a), perigeo, apogeo y alturas en kilómetros.
    """

    MU_TIERRA = 398600.4418  # Constante gravitacional de la Tierra (km^3/s^2)
    RADIO_TIERRA = 6378.137  # Radio ecuatorial de la Tierra (km)

    resultados = {}

    mean_motion = satelite.get("MEAN_MOTION")
    excentricidad = satelite.get("ECCENTRICITY", 0)

    if mean_motion is None or mean_motion <= 0:
        print("Error: MEAN_MOTION inválido o faltante.")
        return resultados

    # Convertir movimiento medio (rev/día) a velocidad angular (rad/s)
    n_rad_s = (mean_motion * 2 * math.pi) / 86400.0

    # Tercera Ley de Kepler: a = (mu / n^2)^(1/3)
    semieje_mayor = (MU_TIERRA / (n_rad_s ** 2)) ** (1 / 3)

    # Radios desde el centro de la Tierra (en km)
    radio_perigeo = semieje_mayor * (1 - excentricidad)
    radio_apogeo = semieje_mayor * (1 + excentricidad)


    resultados["semieje_mayor_km"] = semieje_mayor
    resultados["radio_perigeo_km"] = radio_perigeo
    resultados["radio_apogeo_km"] = radio_apogeo
    resultados["altura_perigeo_km"] = radio_perigeo - RADIO_TIERRA
    resultados["altura_apogeo_km"] = radio_apogeo - RADIO_TIERRA

    return resultados


def normalizar_parametros(fisica):

    """
    ... Reutiliza el diccionario de salida generado por `calcular_parametros_fisicos`
    ... (que contiene 'semieje_mayor_km', 'radio_perigeo_km' y 'radio_apogeo_km')
    ... para escalar las distancias a Radios Terrestres (RT = 6371.0 km).
    """

    RADIO_TIERRA = 6378.137
    normalizados = {}

    if not fisica or "semieje_mayor_km" not in fisica:
        print("Se requiere el diccionario válido generado por 'calcular_parametros_fisicos'.")
        return normalizados

    # Reutilizar las distancias en km y dividirlas por el radio de la Tierra
    a_norm = fisica["semieje_mayor_km"] / RADIO_TIERRA
    rp_norm = fisica["radio_perigeo_km"] / RADIO_TIERRA
    ra_norm = fisica["radio_apogeo_km"] / RADIO_TIERRA

    # Validar que el perigeo quede fuera de la esfera terrestre (radio > 1)
    orbita_valida = rp_norm > 1.0

    normalizados["a_norm"] = a_norm
    normalizados["rp_norm"] = rp_norm
    normalizados["ra_norm"] = ra_norm
    normalizados["orbita_valida"] = orbita_valida

    return normalizados



def velocidad_y_tiempo(satelite, fisica, num_puntos=360, factor_aceleracion=600.0):

    """
    ... Reutiliza el diccionario generado por `calcular_parametros_fisicos` para
    ... calcular el período orbital, el perfil de velocidades (ecuación vis-viva)
    ... en cada punto de la elipse y los tiempos escalados para la animación.
    """

    MU_TIERRA = 398600.0
    cinematica = {}

    a = fisica["semieje_mayor_km"]
    e = satelite.get("ECCENTRICITY", 0.0)

    # Período orbital real: T = 2 * pi * sqrt(a^3 / mu)
    periodo_s = 2.0 * math.pi * math.sqrt((a ** 3) / MU_TIERRA)
    periodo_min = periodo_s / 60.0
    duracion_animacion_s = periodo_s / factor_aceleracion

    # Calcular distancia radial r (km) en cada ángulo de la órbita (0 a 2*pi)
    angulos_theta = np.linspace(0, 2 * math.pi, num_puntos)
    radios_r = (a * (1.0 - e ** 2)) / (1.0 + e * np.cos(angulos_theta))

    # Ecuación vis-viva en cada punto: v = sqrt(mu * (2/r - 1/a))
    velocidades_kms = np.sqrt(MU_TIERRA * ((2.0 / radios_r) - (1.0 / a)))

    # Tiempo no uniforme entre puntos (va más rápido en el perigeo)
    # Longitud de arco aproximada ds entre puntos consecutivos: ds ≈ r * d_theta
    d_theta = angulos_theta[1] - angulos_theta[0]
    ds = radios_r[:-1] * d_theta
    v_tramo = (velocidades_kms[:-1] + velocidades_kms[1:]) / 2.0  # Velocidad promedio del tramo

    dt_reales = ds / v_tramo
    dt_animacion = dt_reales / factor_aceleracion

    # Vector de tiempos acumulados (arranca en t = 0)
    tiempos_animacion_s = np.concatenate(([0.0], np.cumsum(dt_animacion)))

    cinematica["periodo_s"] = periodo_s
    cinematica["periodo_min"] = periodo_min
    cinematica["duracion_animacion_s"] = duracion_animacion_s
    cinematica["factor_aceleracion"] = factor_aceleracion
    cinematica["angulos_theta"] = angulos_theta
    cinematica["radios_r_km"] = radios_r
    cinematica["velocidades_kms"] = velocidades_kms
    cinematica["v_perigeo_kms"] = float(np.max(velocidades_kms))
    cinematica["v_apogeo_kms"] = float(np.min(velocidades_kms))
    cinematica["tiempos_animacion_s"] = tiempos_animacion_s

    return cinematica


def rotar_z(puntos: np.ndarray, angulo: float) -> np.ndarray:
    """Recibe puntos de forma (3, N) y un ángulo (rad).

    Devuelve los puntos rotados alrededor del eje Z (eje polar).
    """
    c, s = np.cos(angulo), np.sin(angulo)                      # coseno y seno del ángulo
    x, y, z = puntos                                           # separa las tres coordenadas
    return np.array([c * x - s * y, s * x + c * y, z])         # gira x e y, z no cambia


def lineas_tierra(n_meridianos: int = 12, paralelos=(-60, -30, 0, 30, 60)) -> list:
    """Devuelve una lista de (puntos (3, N), color, ancho) con la malla de la Tierra.

    Incluye meridianos, paralelos, el ecuador (verde) y el meridiano de
    Greenwich (rojo), que sirve para ver la rotación. Radio 1.
    """
    t = np.linspace(0, 2 * np.pi, 120)                         # ángulos para dar la vuelta a un paralelo
    lat = np.linspace(-np.pi / 2, np.pi / 2, 120)              # de polo sur a polo norte
    lineas = []                                                # acá se acumulan todas las líneas
    for k in range(n_meridianos):                              # un meridiano por cada k
        lon = 2 * np.pi * k / n_meridianos                     # longitud de este meridiano
        pts = np.array([np.cos(lat) * np.cos(lon), np.cos(lat) * np.sin(lon), np.sin(lat)])  # puntos sobre la esfera
        if k == 0:
            lineas.append((pts, "tab:red", 2.2))               # Greenwich: rojo y más grueso
        else:
            lineas.append((pts, "tab:blue", 0.6))              # el resto: azul fino
    for grados in paralelos:                                   # un paralelo por cada latitud
        la = np.radians(grados)                                # latitud en radianes
        pts = np.array([np.cos(la) * np.cos(t), np.cos(la) * np.sin(t), np.full_like(t, np.sin(la))])  # círculo a esa latitud
        if grados == 0:
            lineas.append((pts, "tab:green", 1.6))             # ecuador: verde y más grueso
        else:
            lineas.append((pts, "tab:blue", 0.6))              # el resto: azul fino
    return lineas

def dibujar_ejes(ax) -> None:
    """Recibe los ejes 3D de Matplotlib.

    Dibuja el eje polar (norte-sur) y flechas X, Y, Z con etiquetas.
    """
    ax.plot([0, 0], [0, 0], [-1.3, 1.3], color="black", lw=1)  # eje polar: línea que atraviesa la esfera
    largo = 1.6                                                # largo de las flechas (en radios terrestres)
    for dx, dy, dz, nombre in ((1, 0, 0, "X"), (0, 1, 0, "Y"), (0, 0, 1, "Z")):  # una flecha por eje
        ax.quiver(0, 0, 0, dx * largo, dy * largo, dz * largo, color="gray",
                  arrow_length_ratio=0.08, lw=0.8)             # dibuja la flecha desde el centro
        ax.text(dx * (largo + 0.15), dy * (largo + 0.15), dz * (largo + 0.15), nombre, color="gray")  # etiqueta en la punta


def esfera(cx, cy, cz, r, n=30):
    u = np.linspace(0, 2 * np.pi, n)
    v = np.linspace(0, np.pi, n)
    x = cx + r * np.outer(np.cos(u), np.sin(v))
    y = cy + r * np.outer(np.sin(u), np.sin(v))
    z = cz + r * np.outer(np.ones_like(u), np.cos(v))
    return x, y, z

def punto_orbita(t,a,b theta):
    ex = a * np.cos(t)
    ey = b * np.sin(t)
    ez = 0 * t
    ey_rot = ey * np.cos(theta) - ez * np.sin(theta)
    ez_rot = ey * np.sin(theta) + ez * np.cos(theta)
    return ex, ey_rot, ez_rot

def dibujar_pelota(t0, pelota):
    if pelota[0] is not None:
        pelota[0].remove()
    px, py, pz = punto_orbita(t0)
    x2, y2, z2 = esfera(px, py, pz, 0.2)
    pelota[0] = ax.plot_surface(x2, y2, z2, color='orange')    

def actualizar(frame):
    dibujar_pelota(2 * np.pi * frame / 120, None)    

if __name__ == "__main__":                                     # solo corre si ejecutás este archivo directamente
    registros = leer_satelites("satelites.json")
    if registros:
        print(f"\n{inspeccionar_satelite(registros[0])}")
        print(f"\n{calcular_parametros_fisicos(inspeccionar_satelite(registros[0]))}")
        print(f"\n{velocidad_y_tiempo(inspeccionar_satelite(registros[0]), calcular_parametros_fisicos(inspeccionar_satelite(registros[0])))}")

    p = np.array([[1.0], [0.0], [0.0]])                        # un punto sobre el eje X
    print("Punto (1, 0, 0) girado 90 grados (debe ser ~(0, 1, 0)):", rotar_z(p, np.pi / 2).T[0])
    print("Líneas de la malla (debe ser 17):", len(lineas_tierra()))   # 12 meridianos + 5 paralelos

