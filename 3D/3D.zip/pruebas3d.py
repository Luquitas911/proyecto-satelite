import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import Funciones3D as f3d



# Órbita
a, b = 2.0, 1.3
theta = np.radians(30)

t = np.linspace(0, 2 * np.pi, 300)
ox, oy, oz = f3d.punto_orbita(t, a,b,theta)

fig = plt.figure()
ax = fig.add_subplot(projection='3d')

# Elementos fijos
x, y, z = f3d.esfera(0, 0, 0, 1, n=60)
ax.plot_surface(x, y, z, cmap='viridis', alpha=0.8)
ax.plot(ox, oy, oz, color='red', linewidth=2)

ax.set_box_aspect((1, 1, 1))
ax.set_xlim(-2, 2)
ax.set_ylim(-2, 2)
ax.set_zlim(-2, 2)
ax.set_axis_off()

# Pelotita: se dibuja YA desde el principio
pelota = [None]

def dibujar_pelota(t0):
    if pelota[0] is not None:
        pelota[0].remove()
    px, py, pz = punto_orbita(t0)
    x2, y2, z2 = esfera(px, py, pz, 0.2)
    pelota[0] = ax.plot_surface(x2, y2, z2, color='orange')

dibujar_pelota(0)   # posición inicial, así se ve aunque no corra la animación

def actualizar(frame):
    dibujar_pelota(2 * np.pi * frame / 120)

ani = FuncAnimation(fig, actualizar, frames=120, interval=30, blit=False)

plt.show()